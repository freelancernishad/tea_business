
	<section id="ltx-logo-footer">

<div class="container">
    <span class="logo-footer"><img width="478" height="151"
            src="http://chaitan.like-themes.com/wp-content/uploads/2018/06/logo_04.png"
            class="attachment-full size-full" alt="" loading="lazy"
            srcset="http://chaitan.like-themes.com/wp-content/uploads/2018/06/logo_04.png 478w, http://chaitan.like-themes.com/wp-content/uploads/2018/06/logo_04-300x95.png 300w"
            sizes="(max-width: 478px) 100vw, 478px" /></span>
    <div class="ltx-social ltx-nav-second">
        <ul>
            <li><a href="#" target="_self"><span class="fa fa-twitter"></span></a></li>
            <li><a href="#" target="_self"><span class="fa fa-facebook-f"></span></a></li>
            <li><a href="#" target="_self"><span class="fa fa-instagram"></span></a></li>
            <li><a href="#" target="_self"><span class="fa fa-google-plus"></span></a></li>
        </ul><span class="header"><span>Follow us</span></span>
    </div>
</div>
</section>
<section id="ltx-widgets-footer">
<div class="container">
    <div class="row">
        <div class="col-md-4 col-sm-12 col-ms-12  matchHeight clearfix">
            <div class="footer-widget-area">
                <div id="text-4" class="widget widget_text">
                    <h4 class="header-widget">About us</h4>
                    <div class="textwidget">
                        <p><strong class="color-main">Addres:</strong> 21 Newstreet, Chaitan town, India, 109-74
                        </p>
                    </div>
                </div>
                <div id="ltx_icons-3" class="widget widget_ltx_icons">
                    <ul class="social-icons-list">
                        <li><a href="#"><span class="fa fa-phone"></span>+700800-50-800</a></li>

                        <li><a href="#"><span class="fa fa-envelope"></span>manager@chaitan.md</a></li>

                        <li><a href="#"><span class="fa fa-skype"></span>chaitan</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 col-ms-12 hidden-xs hidden-ms hidden-sm matchHeight clearfix">
            <div class="footer-widget-area">
                <div id="ltx_navmenu-2" class="widget widget_ltx_navmenu">
                    <h4 class="header-widget">Explore</h4>
                    <div class="menu-main-menu-container">
                        <ul id="menu-main-menu-1" class="menu">
                            <li
                                class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item current-menu-ancestor current-menu-parent menu-item-has-children menu-item-4552">
                                <a href="/">Home</a>
                            </li>
                            <li
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-3557">
                                <a>About us</a>
                            </li>
                            <li
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-619">
                                <a href="#">Products</a>
                            </li>
                            <li
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-59">
                                <a>Blog</a>
                            </li>
                            <li
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-60">
                                <a>Gallery</a>
                            </li>
                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-46"><a
                                    href="http://chaitan.like-themes.com/contacts/">Contacts</a></li>
                            <li
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-has-mega-menu menu-item-61">
                                <a href="#">Pages</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 col-ms-12 hidden-xs hidden-ms hidden-sm matchHeight clearfix">
            <div class="footer-widget-area">
                <div id="ltx_blogposts-5" class="widget widget_ltx_blogposts">
                    <h4 class="header-widget">Recent News</h4>
                    <div class="items">
                        <div class="post"><a
                                href="http://chaitan.like-themes.com/3-ways-how-to-test-nutaral-indian-tea/"
                                class="photo"><img width="110" height="80"
                                    src="http://chaitan.like-themes.com/wp-content/uploads/2018/06/blog_01-110x80.jpg"
                                    class="attachment-chaitan-tiny size-chaitan-tiny wp-post-image" alt=""
                                    loading="lazy" /></a>
                            <div class="blog-info top"><a
                                    href="http://chaitan.like-themes.com/3-ways-how-to-test-nutaral-indian-tea/"
                                    class="date">February 21, 2018</a><a
                                    href="http://chaitan.like-themes.com/3-ways-how-to-test-nutaral-indian-tea/">
                                    <h6>3 ways how to test nutaral indian tea</h6>
                                </a></div>
                        </div>
                        <div class="post"><a
                                href="http://chaitan.like-themes.com/results-of-international-tea-conference-18/"
                                class="photo"><img width="110" height="80"
                                    src="http://chaitan.like-themes.com/wp-content/uploads/2018/06/blog_02-110x80.jpg"
                                    class="attachment-chaitan-tiny size-chaitan-tiny wp-post-image" alt=""
                                    loading="lazy" /></a>
                            <div class="blog-info top"><a
                                    href="http://chaitan.like-themes.com/results-of-international-tea-conference-18/"
                                    class="date">February 21, 2018</a><a
                                    href="http://chaitan.like-themes.com/results-of-international-tea-conference-18/">
                                    <h6>Results of international tea conference &#8217;18</h6>
                                </a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<footer class="copyright-block">
<div class="container">
    <p><a href="https://themeforest.net/user/like-themes">Like-themes</a> 2018 © All Rights Reserved - <a
            href="https://themeforest.net/user/like-themes">Purchase Theme</a></p><a href="#"
        class="go-top hidden-xs hidden-ms"><span class="fa fa-arrow-up"></span></a>
</div>
</footer>

<script defer src="../assets/js/autoptimize.js">
</script>
</body>

</html>